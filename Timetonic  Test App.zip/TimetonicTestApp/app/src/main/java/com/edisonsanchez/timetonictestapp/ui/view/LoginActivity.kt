package com.edisonsanchez.timetonictestapp.ui.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.activity.viewModels
import com.edisonsanchez.timetonictestapp.R
import com.edisonsanchez.timetonictestapp.ui.viewModel.LoginActivityViewModel
import com.google.android.material.textfield.TextInputEditText

class LoginActivity : AppCompatActivity() {

    private val viewModel : LoginActivityViewModel by viewModels()
    private lateinit var email: TextInputEditText
    private lateinit var password : TextInputEditText
    private lateinit var botonSignIn : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        email = findViewById(R.id.email)
        password = findViewById(R.id.password)
        botonSignIn = findViewById(R.id.boton_login)

    }
}