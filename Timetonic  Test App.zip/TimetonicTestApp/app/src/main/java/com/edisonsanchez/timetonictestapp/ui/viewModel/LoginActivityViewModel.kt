package com.edisonsanchez.timetonictestapp.ui.viewModel

import androidx.lifecycle.ViewModel

class LoginActivityViewModel : ViewModel() {

}